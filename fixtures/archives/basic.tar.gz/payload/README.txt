ZManager fixture payload
