# ZManager CLI

[![CI](https://github.com/tzap-org/zmanager/actions/workflows/ci.yml/badge.svg)](https://github.com/tzap-org/zmanager/actions/workflows/ci.yml)
[![Release](https://github.com/tzap-org/zmanager/actions/workflows/release.yml/badge.svg)](https://github.com/tzap-org/zmanager/actions/workflows/release.yml)
[![Release version](https://img.shields.io/github/v/release/tzap-org/zmanager?include_prereleases&label=release)](https://github.com/tzap-org/zmanager/releases)
[![Downloads](https://img.shields.io/github/downloads/tzap-org/zmanager/total)](https://github.com/tzap-org/zmanager/releases)
[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Coverage](https://img.shields.io/badge/coverage-100%25%20lines-brightgreen.svg)](https://github.com/tzap-org/zmanager/actions/workflows/ci.yml)
[![unsafe forbidden](https://img.shields.io/badge/unsafe-forbidden-success.svg)](https://github.com/rust-secure-code/safety-dance/)
[![Security audit](https://img.shields.io/badge/security-cargo--deny%20%2B%20vet-brightgreen.svg)](deny.toml)

`zm` is a universal file archiver for macOS, Linux, and Windows, built for
high-performance compression, safe extraction, and seamless handling of
virtually any archive format.

The CLI is the open-source part of ZManager. It shares the Rust archive engine
with the desktop GUI app, but it is useful on its own: create clean project
archives, extract a broad set of formats safely, inspect archive contents, and
script archive workflows without opening a GUI.

## Install

Release builds are published on the
[latest release page](https://github.com/tzap-org/zmanager/releases/latest).
For full installation details and checksum examples, see
[docs/INSTALL.md](docs/INSTALL.md).

### macOS

Install from the Homebrew tap:

```sh
brew install tzap-org/zmanager/zmanager
```

### Linux

Install the latest matching release into `$HOME/.local/bin`:

```sh
curl -fsSL https://raw.githubusercontent.com/tzap-org/zmanager/main/install.sh | sh
```

### Windows

Install with WinGet:

```powershell
winget install FrankZhu.ZManagerCLI
```

Future version manifests will use `TzapOrg.ZManagerCLI`; new releases use the
organization-scoped package identity.

## Quick Start

```sh
zm -cf project.zip project/
zm -xf project.zip -C out/

zm create project.tzst project/
zm extract project.tzst -C out/

printf '%s\n' "$ZM_PASSWORD" | zm create backup.tzap project/ --password-stdin
printf '%s\n' "$ZM_PASSWORD" | zm extract backup.tzap -C out/ --password-stdin

zm list project.zip
zm test project.zip
```

The classic flags are there for users who already know archive tools. The
subcommands are there for readable scripts.

## What It Does

- Extracts a broad range of archive, package, disk-image, and raw compression
  formats with safety checks enabled by default.
- Creates `.zip`, `.tzst` (`.tar.zst`), `.tgz` (`.tar.gz`), `.tzap`, `.7z`, and `.aar`/`.aea` (Apple Archive) archives
  with focused defaults.
- Opens common desktop, developer, package, and mobile archive formats by name:
  ZIP, ZIPX, JAR, WAR, IPA, APK, APPX, XPI, 7z, TAR, compressed TAR, RAR,
  CPIO, CPGZ, ISO, XAR, CAB, AR, DEB, RPM, SPK-style tar packages, Apple
  Archives (.aar/.aea), and raw compressed files.
- Supports passworded ZIP, 7z, TZAP, and RAR workflows through stdin or
  prompts; new encrypted ZIP, TZAP, and 7z archives use AES-256 encryption
  paths.
- Protects extraction by default against path traversal, unsafe links,
  duplicate normalized paths, case collisions, and accidental overwrite traps.
- Provides both classic archive flags and readable subcommands.

## Why ZManager

ZManager treats extraction and creation differently:

- **Extract broadly.** Open old, obscure, downloaded, package, mobile, and
  developer archives without knowing which backend normally handles them.
- **Create deliberately.** New archives should use practical, well-supported formats:
  ZIP for universal sharing, TZST (`.tar.zst`) for fast compression, TGZ (`.tar.gz`) for compatibility,
  TZAP for encrypted recoverable archives, 7z for high-compression encrypted archives, and Apple Archive (`.aar`/`.aea`) for Apple platforms.
- **TZAP: a modern, open-source RAR alternative.** The `.tzap` format is engineered to be fast, secure, and resilient: state-of-the-art cryptographic signatures, multi-recipient encryption, secure passphrase protection, and self-healing error recovery.
- **Avoid legacy creation paths.** Old compression methods matter for reading
  existing files, but new archives should use safer and faster defaults.
- **Use strong password protection.** Encrypted ZIP, TZAP, and 7z creation use
  AES-256 paths, and passwords are read through prompts or stdin rather than
  command arguments.

## Safety Model

Archive extraction is hostile-input handling. `zm` rejects or guards against:

- absolute paths and `..` traversal;
- symlink and hardlink escapes;
- duplicate normalized output paths;
- Unicode/case-insensitive path collisions;
- unsafe special files by default;
- excessive expanded-size and compression-ratio cases;
- accidental overwrites unless the requested overwrite mode allows them.

Passwords are not accepted as command arguments. Use the prompt or
`--password-stdin` so secrets do not appear in shell history or process listings.

## Format Support

| Workflow | Formats |
| --- | --- |
| Create archives | `.zip` with Deflate/store and AES-256 encryption, `.tzst` (`.tar.zst`) with Zstandard, `.tgz` (`.tar.gz`) with gzip, `.tzap` with Zstandard plus encryption/recovery metadata, `.7z` with LZMA2 and AES-256 encryption, `.aar`/`.aea` (Apple Archive) |
| ZIP family | `.zip`, `.zipx`, `.jar`, `.war`, `.ipa`, `.apk`, `.appx`, `.xpi`, `.cbz`, `.epub`, split `.z01`… volumes, ZIP-content `.exe` files |
| 7z | `.7z`, `.cb7`, encrypted 7z archives, numbered `.7z.001` volumes |
| RAR | `.rar`, `.cbr`, split `.partN.rar` volumes, RAR4/RAR5, passworded RAR data, encrypted RAR5 headers, Unicode paths, symlinks, hardlinks, and file-reference entries |
| TAR and variants | `.tar`, `.cbt`, `.ustar`, `.pax`, `.tar.gz`, `.tgz`, `.tar.bz2`, `.tbz2`, `.tbz`, `.tar.xz`, `.txz`, `.tar.lzma`, `.tlzma`, `.tzst`, `.tar.zst`, `.tar.lz`, `.tar.lzo`, `.tar.Z`, `.tar.lz4`, `.tar.lrz` |
| TZAP | `.tzap` — a modern, open-source RAR alternative. Secure passphrase or multi-recipient encryption, cryptographic signatures, and self-healing error recovery; passphrase-protected create/list/test/extract |
| Raw compressed files | `.zst`, `.gz`, `.bz2`, `.xz`, `.lzma`, `.lz`, `.br`, `.lz4`, `.lzo`, `.Z`, `.lrz` |
| Packages and containers | `.deb`, `.rpm`, `.a`, `.ar`, `.lib`, `.cpio`, `.cpgz`, `.spk`, `.iso`, `.xar`, `.cab`, `.msi`, `.pkg`, `.lha`, `.lzh`, `.warc`, `.mtree` |
| Disk images | `.dmg` (Apple Disk Image), `.vhd` (Virtual PC/Hyper-V), `.vmdk` (VMware), `.udf` (optical) — extraction resolves MBR/GPT partitions and the inner filesystem (NTFS, FAT/exFAT, ext4, UDF) |
| Apple Archive | `.aar`, `.aea` encrypted Apple Archives (macOS/iOS) |
| Passwords | ZIP, 7z, TZAP, Apple Archive, and RAR list/test/extract through prompt or `--password-stdin` |

Creation is intentionally focused on formats people should use today. Extraction
is intentionally broad, so `zm` can be the one command you try first when
someone sends you an archive.

## Shell Completions

Packages install bash, zsh, and fish completions where the package manager
supports it. The CLI can also print a PowerShell argument completer for manual
Windows setup. For manual setup or troubleshooting, print the script for your
shell:

```sh
source <(zm completions bash)
zm completions zsh > ~/.zfunc/_zm
zm completions fish > ~/.config/fish/completions/zm.fish
```

```powershell
zm completions powershell > zm.ps1
. .\zm.ps1
```

## Output Behavior

Human-readable output uses `--color auto` by default: color is shown only on
terminal streams, and `NO_COLOR` disables automatic color. Use
`--color always` to force color or `--color never` to disable it. JSON output
and raw archive payloads from `--to-stdout` are never colorized.

## Build From Source

GUI and other job-event consumers should follow the phase-aware
[job progress contract](docs/JOB_PROGRESS.md), especially for multi-pass TZAP
creation.

```sh
git clone https://github.com/tzap-org/zmanager.git
cd zmanager
cargo build -p zmanager-cli --release
./target/release/zm --help
```

## Test

```sh
cargo fmt --check
cargo clippy --workspace --all-targets
cargo test --workspace
```

Some compatibility tests use optional external archive tools when installed, but
the core suite is deterministic and should pass without network access.

## Project Links

- [Releases](https://github.com/tzap-org/zmanager/releases)
- [Issues](https://github.com/tzap-org/zmanager/issues)
- [CI](https://github.com/tzap-org/zmanager/actions/workflows/ci.yml)
- [Release workflow](https://github.com/tzap-org/zmanager/actions/workflows/release.yml)
- [CLI guide](docs/CLI.md)
- [Install guide](docs/INSTALL.md)
- [Release maintainer notes](RELEASE.md)

## Repository Layout

- `crates/zmanager-cli`: user-facing `zm` command.
- `crates/zmanager-core`: archive planning, creation, extraction, listing,
  testing, safety checks, and backend routing.
- `crates/zmanager-ffi`: C ABI consumed by the desktop GUI app.
- `crates/zmanager-unrar`: bundled extraction-only UnRAR bridge for passworded
  RAR extraction.
- `fixtures/`: committed compatibility fixtures used by integration tests.
- `fuzz/`: `cargo-fuzz` targets for hostile archive and parser surfaces.
- `packaging/`: Homebrew and WinGet metadata templates.
- `scripts/`: release packaging helpers.
- `.github/workflows/`: CI and release automation.

## License

This workspace is released under the Apache License 2.0. The bundled UnRAR
source has its own extraction-only license; see
[THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and
`vendor/unrar/license.txt`.
